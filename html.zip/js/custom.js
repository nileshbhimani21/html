$(document).ready(function() {
    $('.heroslider').owlCarousel({
      nav:true,
      navText: ["<img src='./images/left.png'/>","<img src='./images/right.png'/>"],
      loop: true,
      items: 1,
      animateOut: 'fadeIn',
      autoplay:true,
      dots:false,
    });
    $('.testimonial').owlCarousel({
      nav:true,
      navText: ["<img src='./images/left.png'/>","<img src='./images/right.png'/>"],
      loop: true,
      items: 1,
      dots:false,
    });
  });